Deep Learning in Python
=======================

README
------

Welcome to Deep Learning in Python!

Your download contains:

1. The Ebook:
	deep_learning_with_python.pdf
2. Sample Code:
	code/

Keep your receipt email, you can use it to re-download your book any time in the future.

Any questions at all, contact me direction via email: jason@MachineLearningMastery.com

Kind Regards,

Jason.

